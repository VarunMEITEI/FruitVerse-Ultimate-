package com.varunmeitei.fruitversego

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
