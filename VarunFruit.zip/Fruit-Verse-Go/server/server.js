'use strict';

const express = require('express');
const http = require('node:http');
const cors = require('cors');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const { Server } = require('socket.io');
const rateLimit = require('express-rate-limit');

const PORT = Number(process.env.PORT || 10000);
const OWNER_USERNAME = String(process.env.OWNER_USERNAME || 'VarunMEITEI');
const OWNER_SETUP_KEY = String(process.env.OWNER_SETUP_KEY || '');
const JWT_SECRET = String(process.env.JWT_SECRET || 'development-only-change-this-secret');
const isProduction = process.env.NODE_ENV === 'production';
if (isProduction && (!process.env.DATABASE_URL || !process.env.JWT_SECRET || !OWNER_SETUP_KEY)) {
  throw new Error('Production setup requires DATABASE_URL, JWT_SECRET, and OWNER_SETUP_KEY.');
}
if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL is required. Add a PostgreSQL database before starting the server.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === 'disable' ? false : { rejectUnauthorized: false },
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
});

const GAME_SERVERS = [
  { id: 'asia-1', name: 'Asia Server 1', region: 'Singapore', capacity: 50 },
  { id: 'asia-2', name: 'Asia Server 2', region: 'Singapore', capacity: 50 },
  { id: 'asia-3', name: 'Asia Server 3', region: 'Singapore', capacity: 50 },
  { id: 'europe-1', name: 'Europe Server 1', region: 'Frankfurt', capacity: 50 },
];
const serverById = new Map(GAME_SERVERS.map((server) => [server.id, server]));

const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer, {
  cors: { origin: true, methods: ['GET', 'POST'] },
  pingInterval: 25000,
  pingTimeout: 20000,
});
app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors({ origin: true }));
app.use(express.json({ limit: '32kb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));

function usernameKey(value) { return String(value || '').trim().toLowerCase(); }
function safeProfile(row) {
  return {
    id: row.id,
    username: row.username,
    role: row.role,
    inventory: Array.isArray(row.inventory) ? row.inventory : [],
    coins: Number(row.coins || 0),
    totalFound: Number(row.total_found || 0),
    currentServer: row.current_server || null,
  };
}
function validFruitId(value) {
  const id = Number(value);
  return Number.isInteger(id) && id >= 1 && id <= 36 ? id : null;
}
function makeToken(row) {
  return jwt.sign({ sub: row.id, username: row.username }, JWT_SECRET, { expiresIn: '7d', issuer: 'fruit-verse-go' });
}
function bearerToken(req) {
  const header = String(req.headers.authorization || '');
  return header.startsWith('Bearer ') ? header.slice(7) : '';
}
async function getUserById(id) {
  const result = await pool.query('SELECT * FROM players WHERE id = $1', [id]);
  return result.rows[0] || null;
}
async function requireAuth(req, res, next) {
  try {
    const token = bearerToken(req);
    if (!token) return res.status(401).json({ error: 'Sign in to your online account first.' });
    const decoded = jwt.verify(token, JWT_SECRET, { issuer: 'fruit-verse-go' });
    const user = await getUserById(decoded.sub);
    if (!user || user.is_banned) return res.status(403).json({ error: 'This account is banned or no longer exists.' });
    req.user = user;
    return next();
  } catch (_error) {
    return res.status(401).json({ error: 'Your online session expired. Please sign in again.' });
  }
}
function requireModerator(req, res, next) {
  if (!['owner', 'admin'].includes(req.user.role)) return res.status(403).json({ error: 'Only an online admin can do that.' });
  return next();
}
function requireOwner(req, res, next) {
  if (req.user.role !== 'owner') return res.status(403).json({ error: 'Only the game owner can change admin roles.' });
  return next();
}
function oneRemoved(items, fruitId) {
  const copy = [...items];
  const index = copy.indexOf(fruitId);
  if (index < 0) return null;
  copy.splice(index, 1);
  return copy;
}
async function roomPlayers(serverId) {
  const sockets = await io.in(serverId).fetchSockets();
  return sockets.map((socket) => ({ username: socket.data.user.username, role: socket.data.user.role }));
}
async function serverList() {
  const counts = await Promise.all(GAME_SERVERS.map(async (server) => [server.id, (await io.in(server.id).fetchSockets()).length]));
  const countMap = new Map(counts);
  return GAME_SERVERS.map((server) => ({ ...server, online: countMap.get(server.id) || 0, status: 'online' }));
}

app.get('/health', (_req, res) => res.json({ ok: true, name: 'Fruit Verse Go Server', version: 1 }));
app.get('/api/servers', async (_req, res) => {
  try { return res.json({ servers: await serverList() }); }
  catch (error) { console.error('servers list failed', error); return res.status(500).json({ error: 'Could not load servers.' }); }
});

app.post('/api/auth/register', async (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  const ownerSetupKey = String(req.body?.ownerSetupKey || '');
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Username must be 3–20 letters, numbers, or underscores.' });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  const isOwnerName = usernameKey(username) === usernameKey(OWNER_USERNAME);
  if (isOwnerName && (!OWNER_SETUP_KEY || ownerSetupKey !== OWNER_SETUP_KEY)) {
    return res.status(403).json({ error: 'The owner account needs the private owner setup key configured by the server host.' });
  }
  if (!isOwnerName && ownerSetupKey) return res.status(400).json({ error: 'The owner setup key is only for the owner account.' });
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO players (username, username_key, password_hash, role)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [username, usernameKey(username), passwordHash, isOwnerName ? 'owner' : 'player'],
    );
    const player = result.rows[0];
    return res.status(201).json({ token: makeToken(player), user: safeProfile(player) });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'That username already exists. Choose another or log in.' });
    console.error('register failed', error);
    return res.status(500).json({ error: 'Account could not be created.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const username = usernameKey(req.body?.username);
  const password = String(req.body?.password || '');
  if (!username || !password) return res.status(400).json({ error: 'Enter username and password.' });
  try {
    const result = await pool.query('SELECT * FROM players WHERE username_key = $1', [username]);
    const player = result.rows[0];
    if (!player || !(await bcrypt.compare(password, player.password_hash))) return res.status(401).json({ error: 'Username or password is incorrect.' });
    if (player.is_banned) return res.status(403).json({ error: 'This account has been banned by the game admins.' });
    await pool.query('UPDATE players SET last_seen = NOW() WHERE id = $1', [player.id]);
    return res.json({ token: makeToken(player), user: safeProfile(player) });
  } catch (error) {
    console.error('login failed', error);
    return res.status(500).json({ error: 'Could not sign in right now.' });
  }
});

app.get('/api/me', requireAuth, (req, res) => res.json({ user: safeProfile(req.user) }));

app.post('/api/collect', requireAuth, async (req, res) => {
  const fruitId = validFruitId(req.body?.fruitId) || Math.floor(Math.random() * 36) + 1;
  try {
    const inventory = Array.isArray(req.user.inventory) ? [...req.user.inventory] : [];
    inventory.push(fruitId);
    const updated = await pool.query(
      'UPDATE players SET inventory = $1::jsonb, coins = coins + 10, total_found = total_found + 1 WHERE id = $2 RETURNING *',
      [JSON.stringify(inventory), req.user.id],
    );
    return res.json({ user: safeProfile(updated.rows[0]), collectedFruitId: fruitId });
  } catch (error) {
    console.error('collect failed', error);
    return res.status(500).json({ error: 'Could not save that fruit.' });
  }
});

app.post('/api/servers/join', requireAuth, async (req, res) => {
  const serverId = String(req.body?.serverId || '');
  if (!serverById.has(serverId)) return res.status(400).json({ error: 'That server does not exist.' });
  try {
    await pool.query('UPDATE players SET current_server = $1 WHERE id = $2', [serverId, req.user.id]);
    return res.json({ ok: true, serverId });
  } catch (error) {
    console.error('server selection failed', error);
    return res.status(500).json({ error: 'Could not save your server choice.' });
  }
});

app.post('/api/trades/request', requireAuth, async (req, res) => {
  const targetName = usernameKey(req.body?.targetUsername);
  const offerFruitId = validFruitId(req.body?.offerFruitId);
  const requestFruitId = validFruitId(req.body?.requestFruitId);
  if (!targetName || !offerFruitId || !requestFruitId) return res.status(400).json({ error: 'Choose a player and two valid fruit IDs.' });
  try {
    const targetResult = await pool.query('SELECT * FROM players WHERE username_key = $1', [targetName]);
    const target = targetResult.rows[0];
    if (!target || target.is_banned) return res.status(404).json({ error: 'That player was not found.' });
    if (target.id === req.user.id) return res.status(400).json({ error: 'You cannot trade with yourself.' });
    if (!(req.user.inventory || []).includes(offerFruitId)) return res.status(400).json({ error: 'You do not own the offered fruit.' });
    if (!(target.inventory || []).includes(requestFruitId)) return res.status(400).json({ error: 'That player does not currently own the requested fruit.' });
    const result = await pool.query(
      `INSERT INTO trades (from_user, to_user, offer_fruit_id, request_fruit_id, status)
       VALUES ($1, $2, $3, $4, 'pending') RETURNING id`,
      [req.user.id, target.id, offerFruitId, requestFruitId],
    );
    for (const socket of await io.fetchSockets()) {
      if (socket.data.playerId === target.id) socket.emit('trade:incoming', { tradeId: result.rows[0].id });
    }
    return res.status(201).json({ ok: true, tradeId: result.rows[0].id, message: 'Trade request sent.' });
  } catch (error) {
    console.error('trade request failed', error);
    return res.status(500).json({ error: 'Could not send the trade request.' });
  }
});

app.get('/api/trades', requireAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT t.id, t.from_user, t.to_user, t.offer_fruit_id, t.request_fruit_id, t.status, t.created_at,
              f.username AS from_username, r.username AS to_username
       FROM trades t JOIN players f ON f.id=t.from_user JOIN players r ON r.id=t.to_user
       WHERE t.status='pending' AND (t.from_user=$1 OR t.to_user=$1)
       ORDER BY t.created_at DESC LIMIT 50`, [req.user.id],
    );
    return res.json({ trades: result.rows.map((row) => ({
      id: row.id, fromUsername: row.from_username, toUsername: row.to_username,
      offerFruitId: row.offer_fruit_id, requestFruitId: row.request_fruit_id,
      incoming: row.to_user === req.user.id, status: row.status, createdAt: row.created_at,
    })) });
  } catch (error) {
    console.error('trade list failed', error);
    return res.status(500).json({ error: 'Could not load trades.' });
  }
});

app.post('/api/trades/:id/accept', requireAuth, async (req, res) => {
  const tradeId = Number(req.params.id);
  if (!Number.isInteger(tradeId) || tradeId < 1) return res.status(400).json({ error: 'Invalid trade ID.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const tradeResult = await client.query('SELECT * FROM trades WHERE id=$1 FOR UPDATE', [tradeId]);
    const trade = tradeResult.rows[0];
    if (!trade || trade.status !== 'pending' || trade.to_user !== req.user.id) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'That incoming trade is no longer available.' });
    }
    const playersResult = await client.query('SELECT * FROM players WHERE id = ANY($1::int[]) ORDER BY id FOR UPDATE', [[trade.from_user, trade.to_user]]);
    const from = playersResult.rows.find((player) => player.id === trade.from_user);
    const to = playersResult.rows.find((player) => player.id === trade.to_user);
    const fromInventory = Array.isArray(from?.inventory) ? from.inventory : [];
    const toInventory = Array.isArray(to?.inventory) ? to.inventory : [];
    const nextFrom = oneRemoved(fromInventory, trade.offer_fruit_id);
    const nextTo = oneRemoved(toInventory, trade.request_fruit_id);
    if (!nextFrom || !nextTo || !from || !to || from.is_banned || to.is_banned) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'One of the players no longer has the offered fruit. The trade was not completed.' });
    }
    nextFrom.push(trade.request_fruit_id);
    nextTo.push(trade.offer_fruit_id);
    await client.query('UPDATE players SET inventory=$1::jsonb WHERE id=$2', [JSON.stringify(nextFrom), from.id]);
    await client.query('UPDATE players SET inventory=$1::jsonb WHERE id=$2', [JSON.stringify(nextTo), to.id]);
    await client.query("UPDATE trades SET status='completed', completed_at=NOW() WHERE id=$1", [trade.id]);
    await client.query('COMMIT');
    for (const socket of await io.fetchSockets()) {
      if (socket.data.playerId === trade.from_user || socket.data.playerId === trade.to_user) socket.emit('trade:updated', { tradeId, status: 'completed' });
    }
    return res.json({ ok: true, message: 'Trade completed safely.' });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('accept trade failed', error);
    return res.status(500).json({ error: 'Could not complete the trade.' });
  } finally { client.release(); }
});

app.post('/api/trades/:id/reject', requireAuth, async (req, res) => {
  const tradeId = Number(req.params.id);
  try {
    const result = await pool.query(
      "UPDATE trades SET status='rejected', completed_at=NOW() WHERE id=$1 AND to_user=$2 AND status='pending' RETURNING id",
      [tradeId, req.user.id],
    );
    if (!result.rowCount) return res.status(404).json({ error: 'That incoming trade is no longer available.' });
    for (const socket of await io.fetchSockets()) {
      if (socket.data.playerId === req.user.id) socket.emit('trade:updated', { tradeId, status: 'rejected' });
    }
    return res.json({ ok: true, message: 'Trade declined.' });
  } catch (error) {
    console.error('reject trade failed', error);
    return res.status(500).json({ error: 'Could not decline the trade.' });
  }
});

app.post('/api/admin/spawn', requireAuth, requireModerator, async (req, res) => {
  const fruitId = validFruitId(req.body?.fruitId);
  const targetName = usernameKey(req.body?.targetUsername) || usernameKey(req.user.username);
  if (!fruitId) return res.status(400).json({ error: 'Fruit ID must be between 1 and 36.' });
  try {
    const targetResult = await pool.query('SELECT * FROM players WHERE username_key=$1', [targetName]);
    const target = targetResult.rows[0];
    if (!target || target.is_banned) return res.status(404).json({ error: 'Target player was not found.' });
    const inventory = Array.isArray(target.inventory) ? [...target.inventory] : [];
    inventory.push(fruitId);
    const updated = await pool.query('UPDATE players SET inventory=$1::jsonb WHERE id=$2 RETURNING *', [JSON.stringify(inventory), target.id]);
    return res.json({ ok: true, user: safeProfile(updated.rows[0]) });
  } catch (error) {
    console.error('admin spawn failed', error);
    return res.status(500).json({ error: 'Could not spawn that fruit.' });
  }
});

app.post('/api/admin/ban', requireAuth, requireModerator, async (req, res) => {
  const targetName = usernameKey(req.body?.username);
  const banned = req.body?.banned !== false;
  if (!targetName) return res.status(400).json({ error: 'Enter a player username.' });
  if (targetName === usernameKey(OWNER_USERNAME)) return res.status(400).json({ error: 'The owner account cannot be banned.' });
  try {
    const result = await pool.query('UPDATE players SET is_banned=$1 WHERE username_key=$2 RETURNING id, username', [banned, targetName]);
    if (!result.rowCount) return res.status(404).json({ error: 'That username was not found.' });
    if (banned) {
      const targetId = result.rows[0].id;
      for (const socket of await io.fetchSockets()) {
        if (socket.data.user?.id === targetId) {
          socket.emit('account:banned', { message: 'This account was banned by an admin.' });
          socket.disconnect(true);
        }
      }
    }
    return res.json({ ok: true, username: result.rows[0].username, banned });
  } catch (error) {
    console.error('ban action failed', error);
    return res.status(500).json({ error: 'Could not update that ban.' });
  }
});

app.post('/api/admin/role', requireAuth, requireOwner, async (req, res) => {
  const targetName = usernameKey(req.body?.username);
  const role = String(req.body?.role || 'player');
  if (!targetName || !['admin', 'player'].includes(role)) return res.status(400).json({ error: 'Choose a username and either admin or player role.' });
  if (targetName === usernameKey(OWNER_USERNAME)) return res.status(400).json({ error: 'The owner role cannot be changed.' });
  try {
    const result = await pool.query('UPDATE players SET role=$1 WHERE username_key=$2 RETURNING username, role', [role, targetName]);
    if (!result.rowCount) return res.status(404).json({ error: 'That username was not found.' });
    for (const socket of await io.fetchSockets()) {
      if (usernameKey(socket.data.user?.username) === targetName) {
        socket.data.user.role = role;
        socket.emit('account:role-changed', { role });
      }
    }
    return res.json({ ok: true, user: result.rows[0] });
  } catch (error) {
    console.error('role action failed', error);
    return res.status(500).json({ error: 'Could not update that role.' });
  }
});

io.use(async (socket, next) => {
  try {
    const token = String(socket.handshake.auth?.token || '');
    if (!token) return next(new Error('Please sign in to your online account.'));
    const decoded = jwt.verify(token, JWT_SECRET, { issuer: 'fruit-verse-go' });
    const user = await getUserById(decoded.sub);
    if (!user || user.is_banned) return next(new Error('This account cannot join online servers.'));
    socket.data.user = safeProfile(user);
    socket.data.playerId = user.id;
    next();
  } catch (_error) { next(new Error('Online session expired. Please sign in again.')); }
});

io.on('connection', (socket) => {
  socket.join('global-chat');
  socket.emit('server:welcome', { message: 'Connected to Fruit Verse Go online services.' });
  socket.on('global:chat', (payload = {}) => {
    const text = String(payload.text || '').trim().replace(/[\u0000-\u001F\u007F]/g, '').slice(0, 180);
    const now = Date.now();
    if (socket.data.lastGlobalChatAt && now - socket.data.lastGlobalChatAt < 900) return;
    if (!text) return;
    socket.data.lastGlobalChatAt = now;
    io.to('global-chat').emit('global:chat', { username: socket.data.user.username, text, at: new Date().toISOString() });
  });
  socket.on('server:join', async (payload = {}) => {
    const serverId = String(payload.serverId || '');
    const server = serverById.get(serverId);
    if (!server) return socket.emit('server:error', { message: 'That server does not exist.' });
    const previous = socket.data.serverId;
    if (previous) socket.leave(previous);
    const members = await io.in(serverId).fetchSockets();
    if (members.length >= server.capacity) return socket.emit('server:error', { message: 'That server is full. Try another one.' });
    socket.data.serverId = serverId;
    socket.join(serverId);
    await pool.query('UPDATE players SET current_server=$1, last_seen=NOW() WHERE id=$2', [serverId, socket.data.playerId]).catch((error) => console.error('could not save current server', error));
    socket.emit('server:joined', { server, players: await roomPlayers(serverId) });
    io.to(serverId).emit('server:players', { serverId, players: await roomPlayers(serverId) });
    if (previous && previous !== serverId) io.to(previous).emit('server:players', { serverId: previous, players: await roomPlayers(previous) });
  });
  socket.on('server:leave', async () => {
    const previous = socket.data.serverId;
    if (!previous) return;
    socket.data.serverId = null;
    socket.leave(previous);
    io.to(previous).emit('server:players', { serverId: previous, players: await roomPlayers(previous) });
  });
  socket.on('server:chat', (payload = {}) => {
    const serverId = socket.data.serverId;
    const text = String(payload.text || '').trim().slice(0, 180);
    const now = Date.now();
    if (socket.data.lastChatAt && now - socket.data.lastChatAt < 900) return;
    if (!serverId || !text) return;
    socket.data.lastChatAt = now;
    io.to(serverId).emit('server:chat', {
      username: socket.data.user.username,
      text,
      at: new Date().toISOString(),
    });
  });
  socket.on('server:spawnFruit', (payload = {}) => {
    const user = socket.data.user;
    const fruitId = validFruitId(payload.fruitId);
    const serverId = socket.data.serverId;
    if (!['owner', 'admin'].includes(user.role)) return socket.emit('server:error', { message: 'Only online admins can spawn world fruits.' });
    if (!serverId || !fruitId) return socket.emit('server:error', { message: 'Join a server and select a valid fruit first.' });
    io.to(serverId).emit('world:fruit', { fruitId, by: user.username, at: new Date().toISOString() });
  });
  socket.on('disconnect', async () => {
    const serverId = socket.data.serverId;
    if (serverId) io.to(serverId).emit('server:players', { serverId, players: await roomPlayers(serverId) });
  });
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS players (
      id SERIAL PRIMARY KEY,
      username VARCHAR(20) NOT NULL,
      username_key VARCHAR(20) UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role VARCHAR(12) NOT NULL DEFAULT 'player' CHECK (role IN ('owner','admin','player')),
      is_banned BOOLEAN NOT NULL DEFAULT FALSE,
      inventory JSONB NOT NULL DEFAULT '[]'::jsonb,
      coins INTEGER NOT NULL DEFAULT 0 CHECK (coins >= 0),
      total_found INTEGER NOT NULL DEFAULT 0 CHECK (total_found >= 0),
      current_server VARCHAR(40),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      last_seen TIMESTAMPTZ,
      CHECK (jsonb_typeof(inventory) = 'array')
    );
    CREATE TABLE IF NOT EXISTS trades (
      id SERIAL PRIMARY KEY,
      from_user INTEGER NOT NULL REFERENCES players(id),
      to_user INTEGER NOT NULL REFERENCES players(id),
      offer_fruit_id INTEGER NOT NULL CHECK (offer_fruit_id BETWEEN 1 AND 36),
      request_fruit_id INTEGER NOT NULL CHECK (request_fruit_id BETWEEN 1 AND 36),
      status VARCHAR(12) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','rejected')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      completed_at TIMESTAMPTZ,
      CHECK (from_user <> to_user)
    );
    CREATE INDEX IF NOT EXISTS idx_trades_incoming ON trades(to_user, status, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_trades_outgoing ON trades(from_user, status, created_at DESC);
  `);
  console.log('PostgreSQL schema is ready.');
}

initDb().then(() => {
  httpServer.listen(PORT, '0.0.0.0', () => console.log(`Fruit Verse Go server listening on port ${PORT}`));
}).catch((error) => {
  console.error('Database startup failed:', error);
  process.exit(1);
});

process.on('SIGTERM', async () => {
  await pool.end().catch(() => {});
  httpServer.close(() => process.exit(0));
});
