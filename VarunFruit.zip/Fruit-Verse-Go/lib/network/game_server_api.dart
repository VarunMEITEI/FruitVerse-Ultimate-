import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;

class GameServerApi {
  GameServerApi({required String baseUrl, required this.token})
      : baseUrl = _cleanBaseUrl(baseUrl);

  final String baseUrl;
  final String token;
  final http.Client _client = http.Client();

  static String _cleanBaseUrl(String value) =>
      value.trim().replaceAll(RegExp(r'/+$'), '');

  static Future<bool> checkHealth(String baseUrl) async {
    final url = _cleanBaseUrl(baseUrl);
    final response = await http
        .get(Uri.parse('$url/health'))
        .timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) return false;
    final body = jsonDecode(response.body);
    return body is Map && body['ok'] == true;
  }

  static Future<Map<String, dynamic>> register({
    required String baseUrl,
    required String username,
    required String password,
    String ownerSetupKey = '',
  }) => _sendAuth(
        baseUrl: baseUrl,
        endpoint: '/api/auth/register',
        body: {
          'username': username.trim(),
          'password': password,
          if (ownerSetupKey.isNotEmpty) 'ownerSetupKey': ownerSetupKey,
        },
      );

  static Future<Map<String, dynamic>> login({
    required String baseUrl,
    required String username,
    required String password,
  }) => _sendAuth(
        baseUrl: baseUrl,
        endpoint: '/api/auth/login',
        body: {'username': username.trim(), 'password': password},
      );

  static Future<Map<String, dynamic>> _sendAuth({
    required String baseUrl,
    required String endpoint,
    required Map<String, dynamic> body,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('${_cleanBaseUrl(baseUrl)}$endpoint'),
            headers: const {'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 15));
      final data = _decode(response);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw GameServerException(_errorText(data, 'Online sign-in failed.'));
      }
      return data;
    } on GameServerException {
      rethrow;
    } on TimeoutException {
      throw GameServerException('The server took too long to answer. Try again.');
    } catch (error) {
      throw GameServerException('Cannot reach that server. Check the server URL and internet connection. ($error)');
    }
  }

  Future<Map<String, dynamic>> _request(
    String method,
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final uri = Uri.parse('$baseUrl$path');
    final headers = <String, String>{
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    };
    late http.Response response;
    try {
      if (method == 'GET') {
        response = await _client.get(uri, headers: headers).timeout(const Duration(seconds: 12));
      } else {
        response = await _client
            .post(uri, headers: headers, body: jsonEncode(body ?? const {}))
            .timeout(const Duration(seconds: 12));
      }
    } on TimeoutException {
      throw GameServerException('Server timeout. Please try again.');
    } catch (error) {
      throw GameServerException('Cannot contact the online server. ($error)');
    }
    final data = _decode(response);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw GameServerException(_errorText(data, 'Online request failed.'));
    }
    return data;
  }

  static Map<String, dynamic> _decode(http.Response response) {
    try {
      final value = jsonDecode(response.body);
      if (value is Map<String, dynamic>) return value;
      return <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  static String _errorText(Map<String, dynamic> data, String fallback) =>
      (data['error'] is String && (data['error'] as String).isNotEmpty)
          ? data['error'] as String
          : fallback;

  Future<Map<String, dynamic>> getProfile() => _request('GET', '/api/me');

  Future<Map<String, dynamic>> collectFruit(int fruitId) =>
      _request('POST', '/api/collect', body: {'fruitId': fruitId});

  Future<List<Map<String, dynamic>>> getServers() async {
    final uri = Uri.parse('$baseUrl/api/servers');
    http.Response response;
    try {
      response = await _client.get(uri).timeout(const Duration(seconds: 12));
    } catch (error) {
      throw GameServerException('Could not load the server list. ($error)');
    }
    final data = _decode(response);
    if (response.statusCode != 200) {
      throw GameServerException(_errorText(data, 'Could not load servers.'));
    }
    final list = data['servers'];
    if (list is! List) return <Map<String, dynamic>>[];
    return list.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
  }

  Future<Map<String, dynamic>> saveServerChoice(String serverId) =>
      _request('POST', '/api/servers/join', body: {'serverId': serverId});

  Future<Map<String, dynamic>> adminSpawnFruit({
    required int fruitId,
    String? targetUsername,
  }) => _request('POST', '/api/admin/spawn', body: {
        'fruitId': fruitId,
        if (targetUsername != null && targetUsername.trim().isNotEmpty)
          'targetUsername': targetUsername.trim(),
      });

  Future<Map<String, dynamic>> banPlayer(String username, bool banned) =>
      _request('POST', '/api/admin/ban', body: {'username': username, 'banned': banned});

  Future<Map<String, dynamic>> setPlayerAdmin(String username, bool makeAdmin) =>
      _request('POST', '/api/admin/role', body: {'username': username, 'role': makeAdmin ? 'admin' : 'player'});

  Future<List<Map<String, dynamic>>> getTrades() async {
    final data = await _request('GET', '/api/trades');
    final trades = data['trades'];
    if (trades is! List) return <Map<String, dynamic>>[];
    return trades.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
  }

  Future<Map<String, dynamic>> requestTrade({
    required String targetUsername,
    required int offerFruitId,
    required int requestFruitId,
  }) => _request('POST', '/api/trades/request', body: {
        'targetUsername': targetUsername.trim(),
        'offerFruitId': offerFruitId,
        'requestFruitId': requestFruitId,
      });

  Future<Map<String, dynamic>> resolveTrade(int tradeId, {required bool accept}) =>
      _request('POST', '/api/trades/$tradeId/${accept ? 'accept' : 'reject'}');

  void dispose() => _client.close();
}

class GameServerException implements Exception {
  const GameServerException(this.message);
  final String message;
  @override
  String toString() => message;
}

class GameServerRealtime {
  GameServerRealtime(GameServerApi api)
      : _socket = IO.io(
          api.baseUrl,
          <String, dynamic>{
            'transports': <String>['websocket'],
            'autoConnect': false,
            'reconnection': true,
            'auth': <String, dynamic>{'token': api.token},
          },
        ) {
    _socket.onConnect((_) {
      _setStatus('Connected');
      final serverId = _selectedServer;
      if (serverId != null) _socket.emit('server:join', <String, dynamic>{'serverId': serverId});
    });
    _socket.onDisconnect((_) => _setStatus('Disconnected'));
    _socket.onConnectError((error) => _setStatus('Connection error: $error'));
    _socket.on('server:joined', (data) {
      if (data is Map) {
        final players = data['players'];
        if (players is List) _players.add(players.whereType<Map>().map((p) => Map<String, dynamic>.from(p)).toList());
      }
    });
    _socket.on('server:players', (data) {
      if (data is Map) {
        final players = data['players'];
        if (players is List) _players.add(players.whereType<Map>().map((p) => Map<String, dynamic>.from(p)).toList());
      }
    });
    _socket.on('server:chat', (data) {
      if (data is Map) _chat.add(Map<String, dynamic>.from(data));
    });
    _socket.on('global:chat', (data) {
      if (data is Map) _globalChat.add(Map<String, dynamic>.from(data));
    });
    _socket.on('world:fruit', (data) {
      if (data is Map) _fruitEvents.add(Map<String, dynamic>.from(data));
    });
    _socket.on('server:error', (data) {
      if (data is Map) _errors.add('${data['message'] ?? 'Server error'}');
    });
    _socket.on('account:banned', (data) {
      if (data is Map) _errors.add('${data['message'] ?? 'This account was banned.'}');
    });
    _socket.connect();
  }

  final IO.Socket _socket;
  final StreamController<String> _status = StreamController<String>.broadcast();
  final StreamController<List<Map<String, dynamic>>> _players = StreamController<List<Map<String, dynamic>>>.broadcast();
  final StreamController<Map<String, dynamic>> _chat = StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _globalChat = StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<Map<String, dynamic>> _fruitEvents = StreamController<Map<String, dynamic>>.broadcast();
  final StreamController<String> _errors = StreamController<String>.broadcast();
  String? _selectedServer;
  String currentStatus = 'Connecting…';

  void _setStatus(String value) {
    currentStatus = value;
    if (!_status.isClosed) _status.add(value);
  }

  Stream<String> get status => _status.stream;
  Stream<List<Map<String, dynamic>>> get players => _players.stream;
  Stream<Map<String, dynamic>> get chatMessages => _chat.stream;
  Stream<Map<String, dynamic>> get globalChatMessages => _globalChat.stream;
  Stream<Map<String, dynamic>> get fruitEvents => _fruitEvents.stream;
  Stream<String> get errors => _errors.stream;
  String? get selectedServer => _selectedServer;

  void joinServer(String serverId) {
    _selectedServer = serverId;
    _socket.emit('server:join', <String, dynamic>{'serverId': serverId});
  }

  void leaveServer() {
    _socket.emit('server:leave');
    _selectedServer = null;
    _players.add(<Map<String, dynamic>>[]);
  }

  void sendChat(String text) => _socket.emit('server:chat', <String, dynamic>{'text': text});
  void sendGlobalChat(String text) => _socket.emit('global:chat', <String, dynamic>{'text': text});
  void spawnWorldFruit(int fruitId) => _socket.emit('server:spawnFruit', <String, dynamic>{'fruitId': fruitId});

  void dispose() {
    _socket.dispose();
    _status.close();
    _players.close();
    _chat.close();
    _globalChat.close();
    _fruitEvents.close();
    _errors.close();
  }
}
