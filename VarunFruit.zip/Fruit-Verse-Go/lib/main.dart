import 'dart:async';
import 'dart:math' as math;

import 'package:ar_flutter_plugin/ar_flutter_plugin.dart';
import 'package:ar_flutter_plugin/datatypes/config_planedetection.dart';
import 'package:ar_flutter_plugin/datatypes/hittest_result_types.dart';
import 'package:ar_flutter_plugin/datatypes/node_types.dart';
import 'package:ar_flutter_plugin/managers/ar_anchor_manager.dart';
import 'package:ar_flutter_plugin/managers/ar_location_manager.dart';
import 'package:ar_flutter_plugin/managers/ar_object_manager.dart';
import 'package:ar_flutter_plugin/managers/ar_session_manager.dart';
import 'package:ar_flutter_plugin/models/ar_anchor.dart';
import 'package:ar_flutter_plugin/models/ar_hittest_result.dart';
import 'package:ar_flutter_plugin/models/ar_node.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vector_math/vector_math_64.dart';
import 'network/game_server_api.dart';

void main() => runApp(const FruitVerseGo());

const String ownerAdminName = 'VarunMEITEI';
const List<String> demoTradePartners = ['FruitBot Alpha', 'FruitBot Beta', 'FruitBot Gamma'];
const List<String> demoPlayers = [
  'FruitHunter01',
  'FruitHunter02',
  'NoobCollector',
  'LegendFinder',
  'DragonHunter',
];

String normalizeName(String value) => value.trim().toLowerCase();
String profileKey(String username, String field) => 'profile_${normalizeName(username)}_$field';

class FruitVerseGo extends StatelessWidget {
  const FruitVerseGo({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Fruit Verse Go',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF8B35D1),
            brightness: Brightness.dark,
          ),
          scaffoldBackgroundColor: const Color(0xFF14121A),
          useMaterial3: true,
        ),
        home: const WelcomeGate(),
      );
}

class WelcomeGate extends StatefulWidget {
  const WelcomeGate({super.key});

  @override
  State<WelcomeGate> createState() => _WelcomeGateState();
}

class _WelcomeGateState extends State<WelcomeGate> {
  bool _showLogin = false;
  bool _obscurePassword = true;
  final _username = TextEditingController();
  final _password = TextEditingController();
  final _ownerSetupKey = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _showLogin = true);
    });
  }

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    _ownerSetupKey.dispose();
    super.dispose();
  }

  Future<void> _showServerSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final controller = TextEditingController(text: prefs.getString('api_base_url') ?? '');
    if (!mounted) return;
    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Online server settings'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Paste the URL of your deployed Fruit Verse Go server. Example: https://your-game-server.onrender.com'),
          const SizedBox(height: 12),
          TextField(controller: controller, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Server URL', hintText: 'https://...')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('CANCEL')),
          TextButton(onPressed: () async {
            final url = controller.text.trim().replaceAll(RegExp(r'/+$'), '');
            if (url.isEmpty) {
              Navigator.pop(dialogContext, false);
              return;
            }
            try {
              final ok = await GameServerApi.checkHealth(url);
              if (dialogContext.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Server connected!' : 'Server did not return a healthy response.')));
              }
            } catch (_) {
              if (dialogContext.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not reach this server. Check the URL.')));
            }
          }, child: const Text('TEST')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('SAVE')),
        ],
      ),
    );
    if (saved == true) {
      await prefs.setString('api_base_url', controller.text.trim().replaceAll(RegExp(r'/+$'), ''));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Server URL saved. Create an online account or log in.')));
    }
    controller.dispose();
  }

  Future<void> _enterOnline(Map<String, dynamic> authData, String baseUrl) async {
    final prefs = await SharedPreferences.getInstance();
    final token = authData['token']?.toString() ?? '';
    final user = authData['user'] is Map ? Map<String, dynamic>.from(authData['user'] as Map) : <String, dynamic>{};
    final name = user['username']?.toString() ?? _username.text.trim();
    if (token.isEmpty || name.isEmpty) throw const GameServerException('Server sign-in did not return an account session.');
    await prefs.setString('api_base_url', baseUrl);
    await prefs.setString('online_token', token);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => GameHomePage(
        username: name,
        onlineApi: GameServerApi(baseUrl: baseUrl, token: token),
        accountRole: user['role']?.toString() ?? 'player',
      ),
    ));
  }

  Future<void> _enterGame(String username) async {
    final name = username.trim();
    final prefs = await SharedPreferences.getInstance();
    final banned = (prefs.getStringList('local_banned_users') ?? [])
        .map(normalizeName)
        .contains(normalizeName(name));
    final isOwner = normalizeName(name) == normalizeName(ownerAdminName);
    if (banned && !isOwner) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This username is banned in this demo on this device.')),
        );
      }
      return;
    }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => GameHomePage(username: name)),
    );
  }

  Future<void> _login() async {
    if (_username.text.trim().isEmpty || _password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a username and password, or choose Play as Guest.')),
      );
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = (prefs.getString('api_base_url') ?? '').trim();
    if (baseUrl.isEmpty) {
      await _enterGame(_username.text.trim());
      return;
    }
    setState(() => _busy = true);
    try {
      final data = await GameServerApi.login(baseUrl: baseUrl, username: _username.text, password: _password.text);
      await _enterOnline(data, baseUrl);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _registerOnline() async {
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = (prefs.getString('api_base_url') ?? '').trim();
    if (baseUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('First open SERVER SETTINGS and save your server URL.')));
      await _showServerSettings();
      return;
    }
    if (_username.text.trim().isEmpty || _password.text.length < 8) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a username and a password with at least 8 characters.')));
      return;
    }
    setState(() => _busy = true);
    try {
      final data = await GameServerApi.register(
        baseUrl: baseUrl,
        username: _username.text,
        password: _password.text,
        ownerSetupKey: _ownerSetupKey.text.trim(),
      );
      await _enterOnline(data, baseUrl);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _guestPlay() => _enterGame('Guest${DateTime.now().millisecondsSinceEpoch % 100000}');

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF9B4DFF);
    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF21143A), Color(0xFF111018), Color(0xFF25102D)],
          ),
        ),
        child: SafeArea(
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 450),
            child: !_showLogin
                ? Column(
                    key: const ValueKey('loading'),
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 116,
                        height: 116,
                        decoration: BoxDecoration(
                          color: purple.withOpacity(.18),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: purple, width: 2),
                        ),
                        child: const Icon(Icons.auto_awesome, size: 70, color: Color(0xFFFFD54F)),
                      ),
                      const SizedBox(height: 24),
                      const Text('FRUIT VERSE GO', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900, letterSpacing: 2)),
                      const SizedBox(height: 10),
                      const Text('Your next rare fruit is out there…', style: TextStyle(color: Colors.white70)),
                      const SizedBox(height: 34),
                      const SizedBox(width: 170, child: LinearProgressIndicator(minHeight: 5, color: Color(0xFFFFD54F), backgroundColor: Colors.white12)),
                      const SizedBox(height: 12),
                      const Text('LOADING ADVENTURE', style: TextStyle(color: Colors.white54, letterSpacing: 2, fontSize: 11)),
                    ],
                  )
                : Center(
                    key: const ValueKey('login'),
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 420),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Icon(Icons.travel_explore, size: 68, color: Color(0xFFFFD54F)),
                            const SizedBox(height: 12),
                            const Text('WELCOME, HUNTER!', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                            const SizedBox(height: 8),
                            const Text('Sign in to start your fruit adventure', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70)),
                            const SizedBox(height: 30),
                            TextField(
                              controller: _username,
                              textInputAction: TextInputAction.next,
                              autofillHints: const [AutofillHints.username],
                              decoration: InputDecoration(labelText: 'Username', prefixIcon: const Icon(Icons.person_outline), filled: true, fillColor: Colors.white.withOpacity(.06), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
                            ),
                            const SizedBox(height: 14),
                            TextField(
                              controller: _password,
                              obscureText: _obscurePassword,
                              autofillHints: const [AutofillHints.password],
                              onSubmitted: (_) => _login(),
                              decoration: InputDecoration(
                                labelText: 'Password',
                                prefixIcon: const Icon(Icons.lock_outline),
                                filled: true,
                                fillColor: Colors.white.withOpacity(.06),
                                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
                                suffixIcon: IconButton(icon: Icon(_obscurePassword ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _obscurePassword = !_obscurePassword)),
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _ownerSetupKey,
                              obscureText: true,
                              decoration: const InputDecoration(labelText: 'Owner setup key (owner account only)', prefixIcon: Icon(Icons.key), helperText: 'Leave blank for normal players.'),
                            ),
                            const SizedBox(height: 16),
                            FilledButton(onPressed: _busy ? null : _login, style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.symmetric(vertical: 16)), child: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('LOG IN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1))),
                            const SizedBox(height: 8),
                            OutlinedButton(onPressed: _busy ? null : _registerOnline, style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14), side: const BorderSide(color: Colors.white30)), child: const Text('CREATE ONLINE ACCOUNT')),
                            const SizedBox(height: 8),
                            TextButton.icon(onPressed: _showServerSettings, icon: const Icon(Icons.dns_outlined), label: const Text('SERVER SETTINGS')),
                            OutlinedButton(onPressed: _guestPlay, style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15), side: const BorderSide(color: Colors.white30)), child: const Text('PLAY OFFLINE AS GUEST')),
                            const SizedBox(height: 12),
                            const Text('Online accounts need a deployed server URL. Guest play is offline and does not sync with other players.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}

class FruitEntry {
  const FruitEntry({required this.id, required this.name, required this.rarity, required this.image});
  final int id;
  final String name;
  final String rarity;
  final String image;
}

// The icon assets are preserved from the supplied fruit chart. The chart did not
// provide reliably readable names for every icon, so these numbered labels stay honest.
const List<FruitEntry> fruitCatalog = [
  FruitEntry(id: 1, name: 'Fruit 01', rarity: 'Mythical', image: 'assets/fruits/fruit_01.png'),
  FruitEntry(id: 2, name: 'Fruit 02', rarity: 'Mythical', image: 'assets/fruits/fruit_02.png'),
  FruitEntry(id: 3, name: 'Fruit 03', rarity: 'Mythical', image: 'assets/fruits/fruit_03.png'),
  FruitEntry(id: 4, name: 'Fruit 04', rarity: 'Mythical', image: 'assets/fruits/fruit_04.png'),
  FruitEntry(id: 5, name: 'Fruit 05', rarity: 'Mythical', image: 'assets/fruits/fruit_05.png'),
  FruitEntry(id: 6, name: 'Fruit 06', rarity: 'Mythical', image: 'assets/fruits/fruit_06.png'),
  FruitEntry(id: 7, name: 'Fruit 07', rarity: 'Mythical', image: 'assets/fruits/fruit_07.png'),
  FruitEntry(id: 8, name: 'Fruit 08', rarity: 'Mythical', image: 'assets/fruits/fruit_08.png'),
  FruitEntry(id: 9, name: 'Fruit 09', rarity: 'Legendary', image: 'assets/fruits/fruit_09.png'),
  FruitEntry(id: 10, name: 'Fruit 10', rarity: 'Legendary', image: 'assets/fruits/fruit_10.png'),
  FruitEntry(id: 11, name: 'Fruit 11', rarity: 'Legendary', image: 'assets/fruits/fruit_11.png'),
  FruitEntry(id: 12, name: 'Fruit 12', rarity: 'Legendary', image: 'assets/fruits/fruit_12.png'),
  FruitEntry(id: 13, name: 'Fruit 13', rarity: 'Legendary', image: 'assets/fruits/fruit_13.png'),
  FruitEntry(id: 14, name: 'Fruit 14', rarity: 'Legendary', image: 'assets/fruits/fruit_14.png'),
  FruitEntry(id: 15, name: 'Fruit 15', rarity: 'Legendary', image: 'assets/fruits/fruit_15.png'),
  FruitEntry(id: 16, name: 'Fruit 16', rarity: 'Legendary', image: 'assets/fruits/fruit_16.png'),
  FruitEntry(id: 17, name: 'Fruit 17', rarity: 'Legendary', image: 'assets/fruits/fruit_17.png'),
  FruitEntry(id: 18, name: 'Fruit 18', rarity: 'Legendary', image: 'assets/fruits/fruit_18.png'),
  FruitEntry(id: 19, name: 'Fruit 19', rarity: 'Legendary', image: 'assets/fruits/fruit_19.png'),
  FruitEntry(id: 20, name: 'Fruit 20', rarity: 'Rare', image: 'assets/fruits/fruit_20.png'),
  FruitEntry(id: 21, name: 'Fruit 21', rarity: 'Rare', image: 'assets/fruits/fruit_21.png'),
  FruitEntry(id: 22, name: 'Fruit 22', rarity: 'Rare', image: 'assets/fruits/fruit_22.png'),
  FruitEntry(id: 23, name: 'Fruit 23', rarity: 'Rare', image: 'assets/fruits/fruit_23.png'),
  FruitEntry(id: 24, name: 'Fruit 24', rarity: 'Uncommon', image: 'assets/fruits/fruit_24.png'),
  FruitEntry(id: 25, name: 'Fruit 25', rarity: 'Uncommon', image: 'assets/fruits/fruit_25.png'),
  FruitEntry(id: 26, name: 'Fruit 26', rarity: 'Uncommon', image: 'assets/fruits/fruit_26.png'),
  FruitEntry(id: 27, name: 'Fruit 27', rarity: 'Uncommon', image: 'assets/fruits/fruit_27.png'),
  FruitEntry(id: 28, name: 'Fruit 28', rarity: 'Uncommon', image: 'assets/fruits/fruit_28.png'),
  FruitEntry(id: 29, name: 'Fruit 29', rarity: 'Uncommon', image: 'assets/fruits/fruit_29.png'),
  FruitEntry(id: 30, name: 'Fruit 30', rarity: 'Common', image: 'assets/fruits/fruit_30.png'),
  FruitEntry(id: 31, name: 'Fruit 31', rarity: 'Common', image: 'assets/fruits/fruit_31.png'),
  FruitEntry(id: 32, name: 'Fruit 32', rarity: 'Common', image: 'assets/fruits/fruit_32.png'),
  FruitEntry(id: 33, name: 'Fruit 33', rarity: 'Common', image: 'assets/fruits/fruit_33.png'),
  FruitEntry(id: 34, name: 'Fruit 34', rarity: 'Common', image: 'assets/fruits/fruit_34.png'),
  FruitEntry(id: 35, name: 'Fruit 35', rarity: 'Common', image: 'assets/fruits/fruit_35.png'),
  FruitEntry(id: 36, name: 'Fruit 36', rarity: 'Common', image: 'assets/fruits/fruit_36.png'),
];

Color rarityColor(String rarity) {
  switch (rarity) {
    case 'Mythical': return const Color(0xFFFF6262);
    case 'Legendary': return const Color(0xFFD64BF2);
    case 'Rare': return const Color(0xFF9E82FF);
    case 'Uncommon': return const Color(0xFF63CFFF);
    default: return const Color(0xFFE0E0E0);
  }
}

class GameHomePage extends StatefulWidget {
  const GameHomePage({super.key, required this.username, this.onlineApi, this.accountRole});
  final String username;
  final GameServerApi? onlineApi;
  final String? accountRole;
  @override
  State<GameHomePage> createState() => _GameHomePageState();
}

class _GameHomePageState extends State<GameHomePage> {
  int _tab = 0;
  int coins = 0;
  int totalFound = 0;
  final List<int> inventory = [];
  final Map<String, List<int>> _botInventories = {};
  bool _loaded = false;
  bool _isAdmin = false;
  String _tradePartner = demoTradePartners.first;
  int? _myTradeFruitId;
  int? _partnerTradeFruitId;
  int _adminFruitId = 1;
  final TextEditingController _adminTarget = TextEditingController();
  GameServerRealtime? _realtime;

  @override
  void initState() {
    super.initState();
    if (widget.onlineApi != null) _realtime = GameServerRealtime(widget.onlineApi!);
    _load();
  }

  @override
  void dispose() {
    _adminTarget.dispose();
    _realtime?.dispose();
    widget.onlineApi?.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final savedAdminUsers = (prefs.getStringList('local_admin_users') ?? []).map(normalizeName).toList();
    Map<String, dynamic>? onlineUser;
    if (widget.onlineApi != null) {
      try {
        final profileData = await widget.onlineApi!.getProfile();
        if (profileData['user'] is Map) onlineUser = Map<String, dynamic>.from(profileData['user'] as Map);
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Online account could not load: $error')));
      }
    }
    if (!mounted) return;
    setState(() {
      coins = onlineUser == null ? (prefs.getInt(profileKey(widget.username, 'coins')) ?? 0) : (onlineUser['coins'] as num? ?? 0).toInt();
      totalFound = onlineUser == null ? (prefs.getInt(profileKey(widget.username, 'found')) ?? 0) : (onlineUser['totalFound'] as num? ?? 0).toInt();
      inventory
        ..clear()
        ..addAll(onlineUser == null
            ? (prefs.getStringList(profileKey(widget.username, 'inventory')) ?? []).map(int.tryParse).whereType<int>().where((id) => id >= 1 && id <= fruitCatalog.length)
            : ((onlineUser['inventory'] as List?) ?? []).whereType<num>().map((id) => id.toInt()).where((id) => id >= 1 && id <= fruitCatalog.length));
      _isAdmin = widget.onlineApi != null
          ? ['owner', 'admin'].contains(onlineUser?['role']?.toString() ?? widget.accountRole)
          : normalizeName(widget.username) == normalizeName(ownerAdminName) || savedAdminUsers.contains(normalizeName(widget.username));
      for (final bot in demoTradePartners) {
        final saved = prefs.getStringList('bot_inventory_${normalizeName(bot)}');
        _botInventories[bot] = saved == null
            ? List<int>.generate(3, (_) => math.Random().nextInt(fruitCatalog.length) + 1)
            : saved.map(int.tryParse).whereType<int>().where((id) => id >= 1 && id <= fruitCatalog.length).toList();
      }
      _partnerTradeFruitId = _botInventories[_tradePartner]?.isNotEmpty == true ? _botInventories[_tradePartner]!.first : null;
      _loaded = true;
    });
    await _save();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(profileKey(widget.username, 'coins'), coins);
    await prefs.setInt(profileKey(widget.username, 'found'), totalFound);
    await prefs.setStringList(profileKey(widget.username, 'inventory'), inventory.map((id) => '$id').toList());
    for (final entry in _botInventories.entries) {
      await prefs.setStringList('bot_inventory_${normalizeName(entry.key)}', entry.value.map((id) => '$id').toList());
    }
  }

  Future<void> _collectFruit([FruitEntry? selected]) async {
    final fruit = selected ?? fruitCatalog[math.Random().nextInt(fruitCatalog.length)];
    if (widget.onlineApi != null) {
      try {
        final result = await widget.onlineApi!.collectFruit(fruit.id);
        final user = result['user'] is Map ? Map<String, dynamic>.from(result['user'] as Map) : <String, dynamic>{};
        setState(() {
          inventory
            ..clear()
            ..addAll(((user['inventory'] as List?) ?? []).whereType<num>().map((id) => id.toInt()).where((id) => id >= 1 && id <= fruitCatalog.length));
          coins = (user['coins'] as num? ?? coins).toInt();
          totalFound = (user['totalFound'] as num? ?? totalFound).toInt();
        });
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Fruit could not be saved online: $error')));
        return;
      }
    } else {
      setState(() {
        inventory.add(fruit.id);
        coins += 10;
        totalFound += 1;
      });
      await _save();
    }
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Fruit discovered!'),
        content: Row(children: [
          SizedBox(width: 94, height: 94, child: Image.asset(fruit.image, fit: BoxFit.contain)),
          const SizedBox(width: 12),
          Expanded(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(fruit.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Text(fruit.rarity, style: TextStyle(color: rarityColor(fruit.rarity))),
            const SizedBox(height: 4), const Text('+10 coins'),
          ])),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('AWESOME'))],
      ),
    );
  }

  Future<void> _spawnAdminFruit() async {
    final fruit = fruitCatalog[_adminFruitId - 1];
    if (widget.onlineApi != null) {
      try {
        final target = _adminTarget.text.trim();
        final result = await widget.onlineApi!.adminSpawnFruit(fruitId: fruit.id, targetUsername: target.isEmpty ? widget.username : target);
        if (normalizeName(target.isEmpty ? widget.username : target) == normalizeName(widget.username)) {
          final user = result['user'] is Map ? Map<String, dynamic>.from(result['user'] as Map) : <String, dynamic>{};
          setState(() {
            inventory
              ..clear()
              ..addAll(((user['inventory'] as List?) ?? []).whereType<num>().map((id) => id.toInt()).where((id) => id >= 1 && id <= fruitCatalog.length));
          });
        }
        _realtime?.spawnWorldFruit(fruit.id);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${fruit.name} spawned for ${target.isEmpty ? widget.username : target}${_realtime?.selectedServer == null ? '' : ' and announced in ${_realtime!.selectedServer}'} .')));
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      }
      return;
    }
    setState(() => inventory.add(fruit.id));
    await _save();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Admin spawn: ${fruit.name} added to your inventory.')));
  }

  Future<void> _toggleLocalBan({required bool ban}) async {
    final target = _adminTarget.text.trim();
    if (target.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Type a player username first.')));
      return;
    }
    if (normalizeName(target) == normalizeName(ownerAdminName)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('The owner cannot be banned.')));
      return;
    }
    if (widget.onlineApi != null) {
      try {
        await widget.onlineApi!.banPlayer(target, ban);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ban ? '$target banned on the online server.' : '$target unbanned on the online server.')));
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      }
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final banned = (prefs.getStringList('local_banned_users') ?? []).toList();
    banned.removeWhere((name) => normalizeName(name) == normalizeName(target));
    if (ban) banned.add(target);
    await prefs.setStringList('local_banned_users', banned);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ban ? '$target banned on this device.' : '$target unbanned on this device.')));
  }

  Future<void> _toggleLocalAdmin({required bool grant}) async {
    final target = _adminTarget.text.trim();
    if (target.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Type a player username first.')));
      return;
    }
    if (normalizeName(target) == normalizeName(ownerAdminName)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('The owner role cannot be changed.')));
      return;
    }
    if (widget.onlineApi != null) {
      try {
        await widget.onlineApi!.setPlayerAdmin(target, grant);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(grant ? '$target is now an online admin.' : '$target is now a normal player.')));
      } catch (error) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      }
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final admins = (prefs.getStringList('local_admin_users') ?? []).toList();
    admins.removeWhere((name) => normalizeName(name) == normalizeName(target));
    if (grant) admins.add(target);
    await prefs.setStringList('local_admin_users', admins);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(grant ? '$target added as local demo admin.' : '$target removed from local demo admins.')));
  }

  Future<void> _completeTrade() async {
    final partnerItems = _botInventories[_tradePartner] ?? [];
    final myId = _myTradeFruitId;
    final theirId = _partnerTradeFruitId;
    if (myId == null || !inventory.contains(myId)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a fruit from your inventory.')));
      return;
    }
    if (theirId == null || !partnerItems.contains(theirId)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose a fruit from the trading bot.')));
      return;
    }
    setState(() {
      inventory.remove(myId);
      inventory.add(theirId);
      partnerItems.remove(theirId);
      partnerItems.add(myId);
      _myTradeFruitId = null;
      _partnerTradeFruitId = partnerItems.isNotEmpty ? partnerItems.first : null;
    });
    await _save();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Trade complete! You received ${fruitCatalog[theirId - 1].name}.')));
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _homeContent(),
      _serverContent(),
      _fruitGrid(fruitCatalog, title: 'Fruit Collection', subtitle: '36 fruit icons • collect them all'),
      _fruitGrid(inventory.map((id) => fruitCatalog[id - 1]).toList().reversed.toList(), title: 'My Inventory', subtitle: '${inventory.length} fruits collected'),
      _tradeContent(),
      if (_isAdmin) _adminContent(),
    ];
    final destinations = <NavigationDestination>[
      const NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Home'),
      const NavigationDestination(icon: Icon(Icons.dns_outlined), selectedIcon: Icon(Icons.dns), label: 'Servers'),
      const NavigationDestination(icon: Icon(Icons.grid_view), label: 'Fruit Book'),
      const NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Inventory'),
      const NavigationDestination(icon: Icon(Icons.swap_horiz), label: 'Trade'),
      if (_isAdmin) const NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), label: 'Admin'),
    ];
    if (_tab >= pages.length) _tab = 0;
    return Scaffold(
      appBar: AppBar(
        title: const Text('🍈 Fruit Verse Go'),
        centerTitle: true,
        actions: [
          Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: Text(widget.username, style: const TextStyle(fontSize: 11, color: Colors.white70)))),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'servers') setState(() => _tab = 1);
              if (value == 'logout') Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const WelcomeGate()), (_) => false);
            },
            itemBuilder: (_) => const [PopupMenuItem(value: 'servers', child: Text('Servers')), PopupMenuItem(value: 'logout', child: Text('Log out'))],
          ),
        ],
      ),
      body: !_loaded ? const Center(child: CircularProgressIndicator()) : pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: destinations,
      ),
    );
  }

  Widget _serverContent() {
    if (widget.onlineApi == null || _realtime == null) {
      return ListView(padding: const EdgeInsets.all(22), children: const [
        Icon(Icons.dns_outlined, size: 56, color: Color(0xFFFFD54F)),
        SizedBox(height: 12),
        Text('ONLINE SERVERS', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        SizedBox(height: 8),
        Text('You are playing offline. To join other players, deploy the server from the ZIP, then log in with an online account.', style: TextStyle(color: Colors.white70)),
        SizedBox(height: 12),
        Text('Included regions: Asia Server 1, Asia Server 2, Asia Server 3, and Europe Server 1.', style: TextStyle(color: Colors.white70)),
      ]);
    }
    return OnlineServersPage(api: widget.onlineApi!, realtime: _realtime!, canAdmin: _isAdmin);
  }

  Future<void> _refreshOnlineProfile() async {
    if (widget.onlineApi == null) return;
    try {
      final result = await widget.onlineApi!.getProfile();
      final user = result['user'] is Map ? Map<String, dynamic>.from(result['user'] as Map) : <String, dynamic>{};
      if (!mounted) return;
      setState(() {
        inventory
          ..clear()
          ..addAll(((user['inventory'] as List?) ?? []).whereType<num>().map((id) => id.toInt()).where((id) => id >= 1 && id <= fruitCatalog.length));
        coins = (user['coins'] as num? ?? coins).toInt();
        totalFound = (user['totalFound'] as num? ?? totalFound).toInt();
      });
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not refresh online inventory: $error')));
    }
  }

  Widget _homeContent() => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF55208A), Color(0xFF123E49)]),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_isAdmin ? 'OWNER CONTROL • ${widget.username.toUpperCase()}' : 'YOUR FRUIT ADVENTURE',
                    style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.0, fontSize: 11)),
                const SizedBox(height: 8),
                const Text('Explore. Discover. Collect.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                const SizedBox(height: 18),
                Row(children: [
                  Expanded(child: _stat('TOTAL FOUND', '$totalFound')),
                  const SizedBox(width: 8),
                  Expanded(child: _stat('COINS', '$coins')),
                  const SizedBox(width: 8),
                  Expanded(child: _stat('INVENTORY', '${inventory.length}')),
                ]),
              ],
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ARHuntPage(onCollect: _collectFruit))),
              icon: const Icon(Icons.camera_alt),
              label: const Text('START CAMERA HUNT'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 52,
            child: FilledButton.icon(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GPSHuntPage(onCollect: (fruit) => _collectFruit(fruit)))),
              icon: const Icon(Icons.location_on),
              label: const Text('START GPS FRUIT HUNT'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 50,
            child: OutlinedButton.icon(
              onPressed: () => _collectFruit(),
              icon: const Icon(Icons.auto_awesome),
              label: const Text('QUICK TEST: DISCOVER A FRUIT'),
            ),
          ),
          const SizedBox(height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('FRUIT PREVIEW', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              TextButton(onPressed: () => setState(() => _tab = 2), child: const Text('VIEW ALL 36')),
            ],
          ),
          SizedBox(
            height: 116,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: fruitCatalog.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, index) => SizedBox(
                width: 96,
                child: Column(children: [
                  Expanded(child: Image.asset(fruitCatalog[index].image, fit: BoxFit.contain)),
                  Text(fruitCatalog[index].name, style: const TextStyle(fontSize: 11), overflow: TextOverflow.ellipsis),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Camera hunts show an on-screen fruit preview. GPS hunts use your phone location and let you collect a nearby spawned fruit. Trading and admin controls work in this offline demo; real online players need a server.',
            style: TextStyle(color: Colors.white70),
          ),
        ],
      );

  Widget _stat(String title, String value) => Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]));

  Widget _fruitGrid(List<FruitEntry> fruits, {required String title, required String subtitle}) {
    final width = MediaQuery.of(context).size.width;
    final count = width > 600 ? 4 : 2;
    return CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white70))]))),
      if (fruits.isEmpty)
        const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('No fruits collected yet. Start a hunt!')))
      else
        SliverPadding(padding: const EdgeInsets.all(12), sliver: SliverGrid.builder(
          itemCount: fruits.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: count, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.78),
          itemBuilder: (context, index) {
            final fruit = fruits[index];
            return Card(clipBehavior: Clip.antiAlias, child: Padding(padding: const EdgeInsets.all(9), child: Column(children: [Expanded(child: Center(child: Image.asset(fruit.image, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)))), const SizedBox(height: 6), Text(fruit.name, style: const TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.center), const SizedBox(height: 2), Text(fruit.rarity, style: TextStyle(color: rarityColor(fruit.rarity), fontSize: 12))])));
          },
        )),
    ]);
  }

  Widget _tradeContent() {
    if (widget.onlineApi != null) {
      return ListView(padding: const EdgeInsets.all(16), children: [
        OnlineTradePanel(api: widget.onlineApi!, inventory: inventory, onInventoryChanged: _refreshOnlineProfile),
      ]);
    }
    final partnerItems = _botInventories[_tradePartner] ?? <int>[];
    final ownUniqueItems = inventory.toSet().toList()..sort();
    final partnerUniqueItems = partnerItems.toSet().toList()..sort();

    List<DropdownMenuItem<int>> fruitOptions(List<int> ids) => ids.map((id) => DropdownMenuItem<int>(
          value: id,
          child: Row(children: [
            Image.asset(fruitCatalog[id - 1].image, width: 34, height: 34),
            const SizedBox(width: 8),
            Expanded(child: Text('${fruitCatalog[id - 1].name} • ${fruitCatalog[id - 1].rarity}')),
          ]),
        )).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('FRUIT TRADING', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('Trade one of your fruits for one from a demo trader. These are offline trading bots, not real players.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 18),
        DropdownButtonFormField<String>(
          value: _tradePartner,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Trading partner', border: OutlineInputBorder()),
          items: demoTradePartners.map((name) => DropdownMenuItem(value: name, child: Text(name))).toList(),
          onChanged: (value) => setState(() {
            if (value != null) {
              _tradePartner = value;
              final items = _botInventories[value] ?? <int>[];
              _partnerTradeFruitId = items.isEmpty ? null : items.first;
            }
          }),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('YOUR OFFER', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (ownUniqueItems.isEmpty)
                const Text('Your inventory is empty. Find a fruit first.')
              else
                DropdownButtonFormField<int>(
                  value: ownUniqueItems.contains(_myTradeFruitId) ? _myTradeFruitId : null,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Choose your fruit', border: OutlineInputBorder()),
                  items: fruitOptions(ownUniqueItems),
                  onChanged: (value) => setState(() => _myTradeFruitId = value),
                ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${_tradePartner.toUpperCase()} OFFERS', style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (partnerUniqueItems.isEmpty)
                const Text('This trader has no fruits left.')
              else
                DropdownButtonFormField<int>(
                  value: partnerUniqueItems.contains(_partnerTradeFruitId) ? _partnerTradeFruitId : null,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Choose their fruit', border: OutlineInputBorder()),
                  items: fruitOptions(partnerUniqueItems),
                  onChanged: (value) => setState(() => _partnerTradeFruitId = value),
                ),
            ]),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: ownUniqueItems.isEmpty || partnerUniqueItems.isEmpty ? null : _completeTrade,
            icon: const Icon(Icons.swap_horiz),
            label: const Text('CONFIRM TRADE'),
          ),
        ),
        const SizedBox(height: 12),
        OutlinedButton(onPressed: () => setState(() => _tab = 3), child: const Text('OPEN MY INVENTORY')),
      ],
    );
  }

  Widget _adminContent() => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('ADMIN PANEL', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text(widget.onlineApi == null ? 'Local demo admin • changes affect only this phone.' : 'Online admin • actions are checked by the server and affect the shared game.', style: const TextStyle(color: Colors.orangeAccent)),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('SPAWN ANY FRUIT', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<int>(
                    value: _adminFruitId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Select fruit', border: OutlineInputBorder()),
                    items: fruitCatalog.map((fruit) => DropdownMenuItem<int>(
                      value: fruit.id,
                      child: Row(children: [
                        Image.asset(fruit.image, width: 36, height: 36),
                        const SizedBox(width: 8),
                        Expanded(child: Text('${fruit.name} • ${fruit.rarity}')),
                      ]),
                    )).toList(),
                    onChanged: (value) => setState(() { if (value != null) _adminFruitId = value; }),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _spawnAdminFruit,
                      icon: const Icon(Icons.add_circle),
                      label: const Text('SPAWN INTO MY INVENTORY'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.onlineApi == null ? 'PLAYER MODERATION (LOCAL DEMO)' : 'ONLINE PLAYER MODERATION', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(widget.onlineApi == null ? 'Type a username below to test a local demo ban.' : 'Type the exact username of an online account.', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  const SizedBox(height: 10),
                  TextField(controller: _adminTarget, decoration: const InputDecoration(labelText: 'Player username', hintText: 'e.g. FruitHunter01', border: OutlineInputBorder())),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.tonalIcon(onPressed: () => _toggleLocalBan(ban: true), icon: const Icon(Icons.block), label: const Text('Ban')),
                      OutlinedButton.icon(onPressed: () => _toggleLocalBan(ban: false), icon: const Icon(Icons.lock_open), label: const Text('Unban')),
                      FilledButton.tonalIcon(onPressed: () => _toggleLocalAdmin(grant: true), icon: const Icon(Icons.admin_panel_settings), label: const Text('Give Admin')),
                      OutlinedButton.icon(onPressed: () => _toggleLocalAdmin(grant: false), icon: const Icon(Icons.remove_moderator), label: const Text('Remove Admin')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('DEMO PLAYER NAMES', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ...demoPlayers.map((name) => ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.person_outline),
                    title: Text(name),
                    trailing: IconButton(
                      tooltip: 'Use this username',
                      icon: const Icon(Icons.north_west),
                      onPressed: () => setState(() => _adminTarget.text = name),
                    ),
                  )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(widget.onlineApi == null ? 'These demo controls are local only and are not secure for a public game.' : 'The server verifies every admin action. Only the owner can grant or remove admin roles.', style: const TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      );

}


class OnlineServersPage extends StatefulWidget {
  const OnlineServersPage({super.key, required this.api, required this.realtime, required this.canAdmin});
  final GameServerApi api;
  final GameServerRealtime realtime;
  final bool canAdmin;

  @override
  State<OnlineServersPage> createState() => _OnlineServersPageState();
}

class _OnlineServersPageState extends State<OnlineServersPage> {
  List<Map<String, dynamic>> _servers = [];
  List<Map<String, dynamic>> _players = [];
  final List<Map<String, dynamic>> _messages = [];
  final List<Map<String, dynamic>> _globalMessages = [];
  final TextEditingController _chatController = TextEditingController();
  final TextEditingController _globalChatController = TextEditingController();
  StreamSubscription<String>? _statusSub;
  StreamSubscription<List<Map<String, dynamic>>>? _playersSub;
  StreamSubscription<Map<String, dynamic>>? _chatSub;
  StreamSubscription<Map<String, dynamic>>? _globalChatSub;
  StreamSubscription<Map<String, dynamic>>? _fruitSub;
  StreamSubscription<String>? _errorSub;
  String _status = 'Connecting…';
  String? _selectedServer;
  bool _loading = true;
  String? _loadError;
  int _fruitId = 1;

  @override
  void initState() {
    super.initState();
    _selectedServer = widget.realtime.selectedServer;
    _status = widget.realtime.currentStatus;
    _refreshServers();
    _statusSub = widget.realtime.status.listen((value) { if (mounted) setState(() => _status = value); });
    _playersSub = widget.realtime.players.listen((value) { if (mounted) setState(() => _players = value); });
    _globalChatSub = widget.realtime.globalChatMessages.listen((value) {
      if (!mounted) return;
      setState(() {
        _globalMessages.add(value);
        if (_globalMessages.length > 80) _globalMessages.removeAt(0);
      });
    });
    _chatSub = widget.realtime.chatMessages.listen((value) {
      if (!mounted) return;
      setState(() {
        _messages.add(value);
        if (_messages.length > 60) _messages.removeAt(0);
      });
    });
    _fruitSub = widget.realtime.fruitEvents.listen((value) {
      if (!mounted) return;
      setState(() {
        _messages.add({'username': 'WORLD', 'text': 'Fruit ${value['fruitId']} spawned by ${value['by']}', 'at': value['at']});
        if (_messages.length > 60) _messages.removeAt(0);
      });
    });
    _errorSub = widget.realtime.errors.listen((value) {
      if (!mounted) return;
      setState(() => _status = value);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
    });
  }

  @override
  void dispose() {
    _statusSub?.cancel();
    _playersSub?.cancel();
    _chatSub?.cancel();
    _globalChatSub?.cancel();
    _fruitSub?.cancel();
    _errorSub?.cancel();
    _chatController.dispose();
    _globalChatController.dispose();
    super.dispose();
  }

  Future<void> _refreshServers() async {
    setState(() { _loading = true; _loadError = null; });
    try {
      final servers = await widget.api.getServers();
      if (mounted) setState(() { _servers = servers; _loading = false; });
    } catch (error) {
      if (mounted) setState(() { _loadError = '$error'; _loading = false; });
    }
  }

  Future<void> _join(Map<String, dynamic> server) async {
    final id = server['id']?.toString() ?? '';
    if (id.isEmpty) return;
    try {
      await widget.api.saveServerChoice(id);
      widget.realtime.joinServer(id);
      if (mounted) {
        setState(() { _selectedServer = id; _players = []; _messages.clear(); });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Joining ${server['name']}…')));
      }
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
    }
  }

  void _sendChat() {
    final text = _chatController.text.trim();
    if (text.isEmpty || _selectedServer == null) return;
    widget.realtime.sendChat(text);
    _chatController.clear();
  }

  void _sendGlobalChat() {
    final text = _globalChatController.text.trim();
    if (text.isEmpty) return;
    widget.realtime.sendGlobalChat(text);
    _globalChatController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: _refreshServers,
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const Text('ONLINE SERVERS', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(_status, style: TextStyle(color: _status == 'Connected' ? Colors.lightGreenAccent : Colors.orangeAccent, fontSize: 12)),
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.public, color: Colors.lightGreenAccent), SizedBox(width: 8), Text('GLOBAL CHAT', style: TextStyle(fontWeight: FontWeight.w900))]),
            const SizedBox(height: 4),
            const Text('Chat with online players from any server.', style: TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 8),
            Container(height: 180, padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(10)), child: _globalMessages.isEmpty
              ? const Center(child: Text('No messages yet. Say hello!', style: TextStyle(color: Colors.white54)))
              : ListView.builder(itemCount: _globalMessages.length, itemBuilder: (context, index) {
                  final item = _globalMessages[index];
                  final stamp = (item['at']?.toString() ?? '');
                  final time = stamp.contains('T') && stamp.length >= 16 ? stamp.substring(11, 16) : '';
                  return Padding(padding: const EdgeInsets.only(bottom: 5), child: Text('${time.isEmpty ? '' : '[$time] '}${item['username'] ?? 'Player'}: ${item['text'] ?? ''}', style: const TextStyle(color: Colors.white)));
                })),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: TextField(controller: _globalChatController, maxLength: 180, decoration: const InputDecoration(counterText: '', hintText: 'Message everyone…', border: OutlineInputBorder()), onSubmitted: (_) => _sendGlobalChat())),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _sendGlobalChat, icon: const Icon(Icons.send)),
            ]),
          ]))),
          const SizedBox(height: 12),
          if (_loading) const Center(child: Padding(padding: EdgeInsets.all(18), child: CircularProgressIndicator())),
          if (_loadError != null) Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text(_loadError!), TextButton(onPressed: _refreshServers, child: const Text('RETRY'))]))),
          ..._servers.map((server) {
            final id = server['id']?.toString() ?? '';
            final selected = id == _selectedServer;
            final online = (server['online'] as num? ?? 0).toInt();
            final capacity = (server['capacity'] as num? ?? 50).toInt();
            return Card(
              child: ListTile(
                leading: Icon(selected ? Icons.wifi_tethering : Icons.dns, color: selected ? Colors.lightGreenAccent : Colors.deepPurpleAccent, size: 30),
                title: Text(server['name']?.toString() ?? id, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${server['region'] ?? 'Unknown region'} • $online/$capacity players'),
                trailing: FilledButton.tonal(onPressed: selected ? null : () => _join(server), child: Text(selected ? 'JOINED' : 'JOIN')),
              ),
            );
          }),
          if (_selectedServer != null) ...[
            const SizedBox(height: 8),
            Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('PLAYERS • ${_players.length}', style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              if (_players.isEmpty) const Text('Waiting for the server roster…', style: TextStyle(color: Colors.white70)),
              Wrap(spacing: 6, runSpacing: 6, children: _players.map((player) => Chip(avatar: Icon(player['role'] == 'owner' ? Icons.star : Icons.person, size: 16), label: Text('${player['username'] ?? 'Player'}${player['role'] == 'owner' ? ' • Owner' : player['role'] == 'admin' ? ' • Admin' : ''}'))).toList()),
            ]))),
            const SizedBox(height: 8),
            if (widget.canAdmin) Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('SPAWN A WORLD FRUIT', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              DropdownButtonFormField<int>(
                value: _fruitId,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Fruit', border: OutlineInputBorder()),
                items: fruitCatalog.map((fruit) => DropdownMenuItem(value: fruit.id, child: Text('${fruit.name} • ${fruit.rarity}'))).toList(),
                onChanged: (value) { if (value != null) setState(() => _fruitId = value); },
              ),
              const SizedBox(height: 8),
              SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => widget.realtime.spawnWorldFruit(_fruitId), icon: const Icon(Icons.auto_awesome), label: const Text('SPAWN FOR THIS SERVER'))),
            ]))),
            Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('SERVER CHAT', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Container(
                height: 190,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(10)),
                child: _messages.isEmpty
                    ? const Center(child: Text('Say hello to players in this server!', style: TextStyle(color: Colors.white54)))
                    : ListView.builder(itemCount: _messages.length, itemBuilder: (context, index) {
                        final item = _messages[index];
                        return Padding(padding: const EdgeInsets.only(bottom: 5), child: Text('${item['username'] ?? 'Player'}: ${item['text'] ?? ''}', style: TextStyle(color: item['username'] == 'WORLD' ? Colors.amberAccent : Colors.white)));
                      }),
              ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: TextField(controller: _chatController, maxLength: 180, decoration: const InputDecoration(counterText: '', hintText: 'Type a message…', border: OutlineInputBorder()), onSubmitted: (_) => _sendChat())),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: _sendChat, icon: const Icon(Icons.send)),
              ]),
              TextButton.icon(onPressed: () { widget.realtime.leaveServer(); setState(() { _selectedServer = null; _players = []; _messages.clear(); }); }, icon: const Icon(Icons.logout), label: const Text('LEAVE SERVER')),
            ]))),
          ],
          const SizedBox(height: 14),
          const Text('Online status, player counts, and chat work only after the server has been deployed and this account has logged in online.', style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }
}

class OnlineTradePanel extends StatefulWidget {
  const OnlineTradePanel({super.key, required this.api, required this.inventory, required this.onInventoryChanged});
  final GameServerApi api;
  final List<int> inventory;
  final Future<void> Function() onInventoryChanged;

  @override
  State<OnlineTradePanel> createState() => _OnlineTradePanelState();
}

class _OnlineTradePanelState extends State<OnlineTradePanel> {
  final TextEditingController _target = TextEditingController();
  List<Map<String, dynamic>> _trades = [];
  int? _offerFruit;
  int _requestFruit = 1;
  bool _busy = false;
  String? _error;

  @override
  void initState() { super.initState(); _refresh(); }

  @override
  void dispose() { _target.dispose(); super.dispose(); }

  Future<void> _refresh() async {
    try {
      final trades = await widget.api.getTrades();
      if (mounted) setState(() { _trades = trades; _error = null; });
    } catch (error) {
      if (mounted) setState(() => _error = '$error');
    }
  }

  Future<void> _sendRequest() async {
    final fruitIds = widget.inventory.toSet().toList()..sort();
    if (_target.text.trim().isEmpty || fruitIds.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a player username and collect a fruit first.')));
      return;
    }
    final offer = fruitIds.contains(_offerFruit) ? _offerFruit! : fruitIds.first;
    setState(() => _busy = true);
    try {
      await widget.api.requestTrade(targetUsername: _target.text.trim(), offerFruitId: offer, requestFruitId: _requestFruit);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Trade request sent!')));
      await _refresh();
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
    } finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _resolve(int id, bool accept) async {
    setState(() => _busy = true);
    try {
      await widget.api.resolveTrade(id, accept: accept);
      if (accept) await widget.onInventoryChanged();
      await _refresh();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(accept ? 'Trade completed!' : 'Trade declined.')));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$error')));
      await _refresh();
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) {
    final fruitIds = widget.inventory.toSet().toList()..sort();
    final offer = fruitIds.contains(_offerFruit) ? _offerFruit : (fruitIds.isEmpty ? null : fruitIds.first);
    return Card(
      child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('PLAYER-TO-PLAYER TRADING', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        const Text('These trades exchange saved fruits between real online accounts. Both players must own the fruit they offer.', style: TextStyle(color: Colors.white70, fontSize: 12)),
        const SizedBox(height: 12),
        TextField(controller: _target, decoration: const InputDecoration(labelText: 'Other player username', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        DropdownButtonFormField<int>(
          value: offer,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Fruit you give', border: OutlineInputBorder()),
          items: fruitIds.map((id) => DropdownMenuItem(value: id, child: Text('${fruitCatalog[id - 1].name} • ${fruitCatalog[id - 1].rarity}'))).toList(),
          onChanged: fruitIds.isEmpty ? null : (value) => setState(() => _offerFruit = value),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<int>(
          value: _requestFruit,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Fruit you want', border: OutlineInputBorder()),
          items: fruitCatalog.map((fruit) => DropdownMenuItem(value: fruit.id, child: Text('${fruit.name} • ${fruit.rarity}'))).toList(),
          onChanged: (value) { if (value != null) setState(() => _requestFruit = value); },
        ),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _busy || fruitIds.isEmpty ? null : _sendRequest, icon: const Icon(Icons.send), label: const Text('SEND TRADE REQUEST'))),
        const Divider(height: 24),
        const Text('PENDING TRADE REQUESTS', style: TextStyle(fontWeight: FontWeight.bold)),
        if (_error != null) Text(_error!, style: const TextStyle(color: Colors.orangeAccent)),
        if (_trades.isEmpty && _error == null) const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Text('No pending trade requests.')),
        ..._trades.map((trade) {
          final id = (trade['id'] as num).toInt();
          final incoming = trade['incoming'] == true;
          final other = incoming ? trade['fromUsername'] : trade['toUsername'];
          final offerId = (trade['offerFruitId'] as num).toInt();
          final wantId = (trade['requestFruitId'] as num).toInt();
          return Card(color: Colors.black26, child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(incoming ? 'From $other' : 'To $other', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text('${fruitCatalog[offerId - 1].name} for ${fruitCatalog[wantId - 1].name}'),
            if (incoming) Row(children: [
              Expanded(child: FilledButton.tonal(onPressed: _busy ? null : () => _resolve(id, true), child: const Text('ACCEPT'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: _busy ? null : () => _resolve(id, false), child: const Text('DECLINE'))),
            ]) else const Text('Waiting for the other player…', style: TextStyle(color: Colors.white60, fontSize: 12)),
          ])));
        }),
        TextButton.icon(onPressed: _refresh, icon: const Icon(Icons.refresh), label: const Text('REFRESH TRADES')),
      ])),
    );
  }
}

class ARHuntPage extends StatefulWidget {
  const ARHuntPage({super.key, required this.onCollect});
  final Future<void> Function([FruitEntry? fruit]) onCollect;

  @override
  State<ARHuntPage> createState() => _ARHuntPageState();
}

class _ARHuntPageState extends State<ARHuntPage> {
  ARSessionManager? _sessionManager;
  ARObjectManager? _objectManager;
  ARAnchorManager? _anchorManager;
  ARAnchor? _fruitAnchor;
  ARNode? _fruitNode;
  bool _arReady = false;
  bool collecting = false;
  late FruitEntry visibleFruit;
  String _message = 'Allow camera access, point at a flat surface, then tap the surface to place the fruit.';

  @override
  void initState() {
    super.initState();
    visibleFruit = fruitCatalog[math.Random().nextInt(fruitCatalog.length)];
  }

  @override
  void dispose() {
    _sessionManager?.dispose();
    super.dispose();
  }

  void _onARViewCreated(
    ARSessionManager sessionManager,
    ARObjectManager objectManager,
    ARAnchorManager anchorManager,
    ARLocationManager locationManager,
  ) {
    _sessionManager = sessionManager;
    _objectManager = objectManager;
    _anchorManager = anchorManager;
    sessionManager.onInitialize(
      showFeaturePoints: false,
      showPlanes: true,
      showWorldOrigin: false,
      handleTaps: true,
    );
    objectManager.onInitialize();
    sessionManager.onPlaneOrPointTap = _onPlaneOrPointTapped;
    if (mounted) {
      setState(() {
        _arReady = true;
        _message = 'Tap a detected floor or tabletop to place ${visibleFruit.name} in the AR scene.';
      });
    }
  }

  Future<void> _onPlaneOrPointTapped(List<ARHitTestResult> hitTestResults) async {
    if (_fruitNode != null) {
      if (mounted) setState(() => _message = 'Fruit is placed! Collect it or choose Find Another Fruit.');
      return;
    }
    ARHitTestResult? hit;
    for (final result in hitTestResults) {
      if (result.type == ARHitTestResultType.plane) {
        hit = result;
        break;
      }
    }
    if (hit == null) {
      if (mounted) setState(() => _message = 'No flat surface detected yet. Move the camera slowly over a floor or table, then tap again.');
      return;
    }

    try {
      final anchor = ARPlaneAnchor(transformation: hit.worldTransform);
      final anchorAdded = await _anchorManager?.addAnchor(anchor);
      if (anchorAdded != true) {
        if (mounted) setState(() => _message = 'Could not place the fruit. Try tapping another detected surface.');
        return;
      }

      final modelPath = "assets/models/fruit_${visibleFruit.id.toString().padLeft(2, '0')}.glb";
      final node = ARNode(
        type: NodeType.localGLTF2,
        uri: modelPath,
        scale: Vector3(0.28, 0.28, 0.28),
        position: Vector3(0.0, 0.0, 0.0),
        rotation: Vector4(1.0, 0.0, 0.0, 0.0),
      );
      final nodeAdded = await _objectManager?.addNode(node, planeAnchor: anchor);
      if (nodeAdded == true) {
        if (mounted) setState(() {
          _fruitAnchor = anchor;
          _fruitNode = node;
          _message = 'Fruit placed in the camera scene! Tap Collect Fruit to add it to your inventory.';
        });
      } else {
        await _anchorManager?.removeAnchor(anchor);
        if (mounted) setState(() => _message = 'The fruit model could not be loaded. Try finding another fruit.');
      }
    } catch (_) {
      if (mounted) setState(() => _message = 'AR placement failed on this device. Check AR support and try again.');
    }
  }

  Future<void> _removePlacedFruit() async {
    final node = _fruitNode;
    final anchor = _fruitAnchor;
    if (node != null) await _objectManager?.removeNode(node);
    if (anchor != null) await _anchorManager?.removeAnchor(anchor);
    if (mounted) setState(() {
      _fruitNode = null;
      _fruitAnchor = null;
    });
  }

  Future<void> _collectPlacedFruit() async {
    if (_fruitNode == null || collecting) return;
    setState(() => collecting = true);
    final fruit = visibleFruit;
    await _removePlacedFruit();
    await widget.onCollect(fruit);
    if (mounted) setState(() {
      collecting = false;
      visibleFruit = fruitCatalog[math.Random().nextInt(fruitCatalog.length)];
      _message = 'Next fruit: ${visibleFruit.name}. Tap a newly detected flat surface to place it.';
    });
  }

  Future<void> _findAnotherFruit() async {
    await _removePlacedFruit();
    if (mounted) setState(() {
      visibleFruit = fruitCatalog[math.Random().nextInt(fruitCatalog.length)];
      _message = _arReady
          ? 'New fruit: ${visibleFruit.name}. Tap a detected floor or tabletop to place it.'
          : 'Waiting for the camera to start…';
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('AR Fruit Hunt')),
        body: Stack(children: [
          Positioned.fill(
            child: ARView(
              onARViewCreated: _onARViewCreated,
              planeDetectionConfig: PlaneDetectionConfig.horizontalAndVertical,
            ),
          ),
          if (_fruitNode == null)
            Center(
              child: IgnorePointer(
                child: Container(
                  width: 170,
                  height: 170,
                  decoration: BoxDecoration(color: Colors.black.withOpacity(.14), borderRadius: BorderRadius.circular(24), border: Border.all(color: Colors.white54, width: 2)),
                  padding: const EdgeInsets.all(12),
                  child: Image.asset(visibleFruit.image, fit: BoxFit.contain),
                ),
              ),
            ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Card(child: Padding(padding: const EdgeInsets.all(12), child: Text('${visibleFruit.name} • ${visibleFruit.rarity}\n${_message}', textAlign: TextAlign.center))),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: FilledButton.icon(
                  onPressed: _fruitNode != null && !collecting ? _collectPlacedFruit : null,
                  icon: const Icon(Icons.add_circle_outline),
                  label: Text(collecting ? 'COLLECTING…' : _fruitNode != null ? 'COLLECT FRUIT' : 'PLACE FRUIT FIRST'),
                ),
              ),
              const SizedBox(height: 6),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: collecting ? null : _findAnotherFruit,
                  icon: const Icon(Icons.refresh),
                  label: const Text('FIND ANOTHER FRUIT'),
                ),
              ),
            ]),
          ),
        ]),
      );
}

class GPSHuntPage extends StatefulWidget {
  const GPSHuntPage({super.key, required this.onCollect});
  final Future<void> Function(FruitEntry fruit) onCollect;
  @override
  State<GPSHuntPage> createState() => _GPSHuntPageState();
}

class _GPSHuntPageState extends State<GPSHuntPage> {
  Position? _position;
  FruitEntry? _spawnedFruit;
  double? _targetLatitude;
  double? _targetLongitude;
  double? _distanceMeters;
  bool _busy = false;
  String? _message;
  static const double _collectRadiusMeters = 25;

  Future<Position> _getPosition() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) throw Exception('Turn on Location/GPS in your phone settings, then tap Scan.');
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied) throw Exception('Location permission was denied. Allow it to use GPS hunting.');
    if (permission == LocationPermission.deniedForever) throw Exception('Location permission is blocked. Change it in Android app settings.');
    return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20)));
  }

  Future<void> _scanOrUpdate() async {
    if (_busy) return;
    setState(() { _busy = true; _message = null; });
    try {
      final p = await _getPosition();
      if (!mounted) return;
      if (_spawnedFruit == null) {
        final random = math.Random();
        final distance = 8 + random.nextDouble() * 14;
        final bearing = random.nextDouble() * math.pi * 2;
        final latitudeDelta = distance * math.cos(bearing) / 111320;
        final longitudeScale = math.max(0.05, math.cos(p.latitude * math.pi / 180).abs());
        final longitudeDelta = distance * math.sin(bearing) / (111320 * longitudeScale);
        setState(() {
          _position = p;
          _targetLatitude = p.latitude + latitudeDelta;
          _targetLongitude = p.longitude + longitudeDelta;
          _spawnedFruit = fruitCatalog[random.nextInt(fruitCatalog.length)];
          _distanceMeters = Geolocator.distanceBetween(p.latitude, p.longitude, _targetLatitude!, _targetLongitude!);
          _message = 'A fruit spawned nearby! Move closer and scan again.';
        });
      } else {
        final dist = Geolocator.distanceBetween(p.latitude, p.longitude, _targetLatitude!, _targetLongitude!);
        setState(() { _position = p; _distanceMeters = dist; _message = dist <= _collectRadiusMeters ? 'You are close enough to collect it!' : 'Keep moving toward the fruit and scan again.'; });
      }
    } catch (e) {
      if (mounted) setState(() => _message = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _collect() async {
    final fruit = _spawnedFruit;
    final distance = _distanceMeters;
    if (fruit == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tap Scan Nearby Fruits first.')));
      return;
    }
    if (distance == null || distance > _collectRadiusMeters) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You are too far away. Tap Update Distance after moving closer.')));
      return;
    }
    await widget.onCollect(fruit);
    if (mounted) setState(() { _spawnedFruit = null; _targetLatitude = null; _targetLongitude = null; _distanceMeters = null; _message = 'Collected! Scan to look for another fruit.'; });
  }

  @override
  Widget build(BuildContext context) {
    final canCollect = _spawnedFruit != null && _distanceMeters != null && _distanceMeters! <= _collectRadiusMeters;
    return Scaffold(
      appBar: AppBar(title: const Text('GPS Fruit Hunt')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(height: 170, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF3D1A68), Color(0xFF14504A)])), child: Center(child: _spawnedFruit == null ? const Icon(Icons.location_searching, size: 80, color: Color(0xFFFFD54F)) : Image.asset(_spawnedFruit!.image, width: 136, height: 136, fit: BoxFit.contain))),
        const SizedBox(height: 18),
        Text(_spawnedFruit == null ? 'Search for a fruit nearby' : '${_spawnedFruit!.name} spotted!', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Text(_spawnedFruit == null ? 'Your phone GPS will spawn a collectible close to your current location.' : '${_spawnedFruit!.rarity} fruit • keep within ${_collectRadiusMeters.toInt()} metres to collect.', style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 14),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_position == null ? 'Location: not checked yet' : 'GPS accuracy: about ${_position!.accuracy.toStringAsFixed(0)} metres'),
          const SizedBox(height: 6),
          Text(_distanceMeters == null ? 'Distance: —' : 'Fruit distance: ${_distanceMeters!.toStringAsFixed(1)} metres', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          if (_message != null) ...[const SizedBox(height: 8), Text(_message!, style: const TextStyle(color: Color(0xFFFFD54F)))],
        ]))),
        const SizedBox(height: 12),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: _busy ? null : _scanOrUpdate,
            icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.radar),
            label: Text(_busy ? 'CHECKING GPS…' : _spawnedFruit == null ? 'SCAN NEARBY FRUITS' : 'UPDATE DISTANCE'),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 52,
          child: FilledButton.icon(onPressed: canCollect ? _collect : null, icon: const Icon(Icons.check_circle), label: const Text('COLLECT FRUIT')),
        ),
        const SizedBox(height: 16),
        const Text('Safety note: check your surroundings and stay in safe, public places. Do not walk into roads or private property while playing.', style: TextStyle(color: Colors.white54, fontSize: 12)),
      ]),
    );
  }
}
