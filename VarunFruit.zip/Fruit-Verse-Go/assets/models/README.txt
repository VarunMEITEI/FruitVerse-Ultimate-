There are 36 local GLB models, one per fruit icon.
Each GLB is a transparent textured plane based on the project's corresponding assets/fruits/fruit_NN.png file. AR mode anchors one of these planes to a surface detected by the phone's AR camera. These are not full volumetric/sculpted fruit models.
