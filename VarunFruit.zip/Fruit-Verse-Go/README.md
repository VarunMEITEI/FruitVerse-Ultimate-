# Fruit Verse Go 🍈🎮

Fruit Verse Go is a Flutter Android fruit-hunting game prototype with an optional online backend. This ZIP is a **source project**, not an installable APK. Use the GitHub Actions workflow to build the Android APK.

## Features in this project

- Loading page, offline guest mode, and online account registration/sign-in.
- Fruit Book with 36 fruit images and 36 GLB model assets.
- Fruit collection, inventory, and +10 coins per collected fruit.
- Camera/AR hunt and GPS hunt prototypes.
- Offline demo trading with bots while playing offline.
- **Online game servers:** Asia Server 1, Asia Server 2, Asia Server 3, and Europe Server 1.
- Online server player lists, real-time chat, and world-fruit announcements.
- **Player-to-player online trade requests**. The server checks ownership and completes both inventory updates in a database transaction.
- **Online moderation:** owner/admin can ban or unban players, and the owner can grant/remove admin roles.
- Owner/admin fruit spawning (to a player's saved inventory and/or as a message in the joined server).
- Server-side password hashing, signed sessions, rate limits, online ban checks, and server-side role checks.
- Offline demo mode stays available without a deployed server.

## Chat features

- **Global Chat** lets signed-in online players talk across all game servers.
- **Server Chat** lets players talk only to others in the server they joined.
- Messages show the sender and a short time stamp, and the server limits message length and rapid sending.
- Chat is live-only in this prototype; messages are not saved as chat history, and chat requires the server to be deployed and reachable.

## Important limits

- The server source is included, but **the server is not hosted yet**. You need to deploy it and enter its URL in the app's **SERVER SETTINGS**.
- The included Render Blueprint makes a free test server + PostgreSQL database. Render currently documents that its free PostgreSQL databases expire 30 days after creation; use a suitable persistent database for a long-term game. See Render's current [free-instance limits](https://render.com/docs/free).
- Free server hosting may sleep while idle and can briefly disconnect players. This is for testing, not a public commercial launch.
- The online world fruit spawn is a real-time server announcement; it is not yet a persistent, geospatial world-spawn system. GPS collection still uses the phone's local GPS logic.
- Camera fruit models depend on ARCore/AR support and surface detection. The included models are simple prototypes.
- The numbered fruit names are temporary (`Fruit 01` to `Fruit 36`) because the original reference did not identify every fruit name clearly.
- Do not use the prototype with payment information or sensitive personal data.

## Deploy the online server using an Android phone

1. Download and extract `VarunFruit.zip`.
2. Open the `Fruit-Verse-Go` folder.
3. In your GitHub repository, choose **Add file → Upload files**. Upload the contents of `Fruit-Verse-Go` into the repository's root. The repository root should contain `pubspec.yaml`, `lib/`, `assets/`, `server/`, `render.yaml`, `android/`, and `.github/`.
4. Commit the uploaded files.
5. In Render, create a **Blueprint** using that GitHub repository and let it read `render.yaml`. Choose a private owner setup key when asked for `OWNER_SETUP_KEY` and keep it private. Never publish it in the repository or send it to other players.
6. Wait for Render to finish deploying the web service and database. Open the service's public URL followed by `/health`. A working server returns JSON similar to `{"ok":true,"name":"Fruit Verse Go Server","version":1}`.
7. Build the Android APK with GitHub: **Actions → Build Fruit Verse Go APK → Run workflow**. After a green check mark, download the `fruit-verse-go-apk` artifact and extract `app-release.apk`.
8. Open the app, tap **SERVER SETTINGS**, paste the Render URL without `/health`, and save it.
9. Create an online account. For the owner account named `VarunMEITEI`, enter the same private owner setup key set in Render. Normal players should leave the owner key blank. Then log in normally on other devices to meet in the servers.

## Server environment settings

The server reads these environment variables:

- `DATABASE_URL`: PostgreSQL connection string.
- `JWT_SECRET`: long random secret used to sign online sessions.
- `OWNER_USERNAME`: owner account name (`VarunMEITEI` by default).
- `OWNER_SETUP_KEY`: private one-time key required when registering the owner account.
- `PORT`: hosting provider's port (Render supplies one automatically).
- `DATABASE_SSL=disable`: optional switch for local PostgreSQL only; do not enable without a reason.

The server uses PostgreSQL tables and automatically creates them on first start. The API health check is `GET /health`; server list is `GET /api/servers`.

## Build the APK

1. Upload the contents of this project folder to the root of your GitHub repository (not the outer folder itself).
2. Open the repository's **Actions** tab.
3. Select **Build Fruit Verse Go APK** and tap **Run workflow** if it did not start automatically.
4. Once it has a green check mark, open the run and download the `fruit-verse-go-apk` artifact.
5. Extract the downloaded artifact and install `app-release.apk` on an Android phone that allows installation from your browser/files app.

If the build fails, share the red workflow's error text. The included workflow formats and analyzes the Dart code before building the APK.
